﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Milkman
{
    class Program
    {
        static bool isDone = false;
        static void Main(string[] args)
        {
            while (!isDone)
            {

                Console.Clear();
                Console.WriteLine("===================================================================");
                Console.WriteLine("\n");
                Console.WriteLine("===================================================================");

        
            }
        }
    }
}
