import os


isDone = False

while not isDone:
    os.system('cls') # on windows()
    print("====================")
    print("\n\n")
    print("===================")